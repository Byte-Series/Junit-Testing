public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public static void main(String[] args) {
        // Example usage
        Calculator calculator = new Calculator();
        int result1 = calculator.add(5, 3);
        int result2 = calculator.subtract(10, 4);

        System.out.println("Addition result: " + result1);
        System.out.println("Subtraction result: " + result2);
    }
}
